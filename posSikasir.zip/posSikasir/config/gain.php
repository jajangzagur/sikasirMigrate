<?php
 return array (
  'app_version' => '1.6.1',
  'update_url' => 'https://marketplace.gainhqs.com',
  'app_id' => 'gain-pos',
  'installed' => true,
) ;