<?php

namespace App\Models;


class OauthAccessToken extends BaseModel
{

}
