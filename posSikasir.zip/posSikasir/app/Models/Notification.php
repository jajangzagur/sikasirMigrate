<?php

namespace App\Models;


class Notification extends BaseModel
{

}
