<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CornJobLog extends BaseModel
{
    protected $fillable = ['branch_id', 'created_at', 'updated_at'];

}
